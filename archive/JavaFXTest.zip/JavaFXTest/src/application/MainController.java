package application;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class MainController {
	
	@FXML
	private Button btnLogin;
	
	@FXML
	private TextField txtUsername;
	
	@FXML
	private PasswordField txtPassword;
	
	public MainController(){
		txtPassword = new PasswordField();
	}
	
	public void loginButtonClicked(){		
		System.out.println("Username: " + txtUsername.getText());
		System.out.println("Password: " + txtPassword.getText());
		
		System.out.println("User logged in...");
		
		txtUsername.clear();
		txtPassword.clear();
	}
	
}
